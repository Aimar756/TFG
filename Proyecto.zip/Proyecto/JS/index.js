var user=document.getElementById("user");
var registro=document.getElementById("registro");
var cerrar = document.getElementById("cerrar");
var capa = document.querySelector(".capa_oscura");
var formu = document.getElementById("registro");
  
user.addEventListener("mousedown",function(){
  capa.style.display = "block";
  formu.style.display = "block";
});

registro.addEventListener("mousedown",function(){
  capa.style.display = "block";
  formu.style.display = "block";
});

cerrar.addEventListener("click",function(){
	capa.style.display="none";
	formu.style.display="none";
});
